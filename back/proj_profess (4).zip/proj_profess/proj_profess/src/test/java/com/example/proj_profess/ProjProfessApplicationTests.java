package com.example.proj_profess;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjProfessApplicationTests {

    @Test
    void contextLoads() {
    }

}
