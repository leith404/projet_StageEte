package com.example.proj_profess.repository;

import com.example.proj_profess.entity.Speciality;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpecialityRepo extends JpaRepository<Speciality, Long> {
}
