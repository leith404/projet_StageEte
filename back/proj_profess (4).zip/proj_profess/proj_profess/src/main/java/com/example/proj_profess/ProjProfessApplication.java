package com.example.proj_profess;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjProfessApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjProfessApplication.class, args);
    }

}
