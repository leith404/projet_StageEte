package com.example.proj_profess.service;

import com.example.proj_profess.entity.Admin;
import com.example.proj_profess.repository.AdminRepo;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor

public class AdminService {


}
